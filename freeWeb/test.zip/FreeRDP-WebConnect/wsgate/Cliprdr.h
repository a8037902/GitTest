#pragma once
class CCliprdr
{
public:
	CCliprdr();
	~CCliprdr();

	bool wf_cliprdr_init(wfContext* wfc, CliprdrClientContext* cliprdr);
	bool wf_cliprdr_uninit(wfContext* wfc, CliprdrClientContext* cliprdr);
};

