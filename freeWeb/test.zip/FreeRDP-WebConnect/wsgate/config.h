/* config.h.in.  Generated from configure.ac by autoheader.  */

/* Whether to compile with SSL support or not */
/* #undef COMPILE_WITH_SSL */

/* GIT revision */
#define GITREV "Unknown"

/* Define to 1 if you have the <arpa/inet.h> header file. */
/* #undef HAVE_ARPA_INET_H */

/* Define to 1 if you have the `bfd_demangle' function. */
/* #undef HAVE_BFD_DEMANGLE */

/* Defined if the requested minimum BOOST version is satisfied */
#define HAVE_BOOST 1

/* Define to 1 if you have <boost/filesystem/path.hpp> */
#define HAVE_BOOST_FILESYSTEM_PATH_HPP 1

/* Define if boost::lock_guard is available */
#define HAVE_BOOST_LOCK_GUARD 1

/* Define to 1 if you have <boost/program_options.hpp> */
#define HAVE_BOOST_PROGRAM_OPTIONS_HPP 1

/* Define to 1 if you have <boost/regex.hpp> */
#define HAVE_BOOST_REGEX_HPP 1

/* Define to 1 if you have <boost/system/error_code.hpp> */
#define HAVE_BOOST_SYSTEM_ERROR_CODE_HPP 1

/* Define to 1 if you have the <conio.h> header file. */
#define HAVE_CONIO_H 1

/* Define to 1 if you have the <cpprest/json.h> header file. */
#define HAVE_CPPREST_JSON_H 1

/* Define to 1 if you have the <demangle.h> header file. */
/* #undef HAVE_DEMANGLE_H */

/* Define to 1 if you have the <dlfcn.h> header file. */
/* #undef HAVE_DLFCN_H */

/* Define to 1 if you don't have `vprintf' but do have `_doprnt.' */
/* #undef HAVE_DOPRNT */

/* Define to 1 if you have the <dwarf.h> header file. */
/* #undef HAVE_DWARF_H */

/* Define to 1 if you have the <ehs.h> header file. */
#define HAVE_EHS_H 1

/* Define to 1 if you have the <elfutils/libdwfl.h> header file. */
/* #undef HAVE_ELFUTILS_LIBDWFL_H */

/* Define to 1 if you have the <execinfo.h> header file. */
/* #undef HAVE_EXECINFO_H */

/* Define to 1 if you have the <fcntl.h> header file. */
#define HAVE_FCNTL_H 1

/* Define to 1 if you have the `fork' function. */
/* #undef HAVE_FORK */

/* Define if the compiler supports GNU-style __PRETTY_FUNCTION__. */
#define HAVE_GNU_PRETTY_FUNCTION 1

/* Define if the compiler supports GNU-style variadic macros. */
/* #undef HAVE_GNU_VAMACROS */

/* Define to 1 if you have the `inet_ntoa' function. */
/* #undef HAVE_INET_NTOA */

/* Define to 1 if you have the <inttypes.h> header file. */
/* #undef HAVE_INTTYPES_H */

/* Define to 1 if you have the <libdwfl.h> header file. */
/* #undef HAVE_LIBDWFL_H */

/* Define, if libiberty is available */
/* #undef HAVE_LIBIBERTY */

/* Define to 1 if you have the <memory.h> header file. */
#define HAVE_MEMORY_H 1

/* Define to 1 if you have the `memset' function. */
#define HAVE_MEMSET 1

/* Define to 1 if you have the <netinet/in.h> header file. */
/* #undef HAVE_NETINET_IN_H */

/* Define to 1 if you have the <openssl/err.h> header file. */
#define HAVE_OPENSSL_ERR_H 1

/* Define to 1 if you have the <openssl/ssl.h> header file. */
#define HAVE_OPENSSL_SSL_H 1

/* Define to 1 if you have the `pthread_getw32threadhandle_np' function. */
/* #undef HAVE_PTHREAD_GETW32THREADHANDLE_NP */

/* Define to 1 if you have the `pthread_getw32threadid_np' function. */
/* #undef HAVE_PTHREAD_GETW32THREADID_NP */

/* Define to 1 if you have the `setlocale' function. */
#define HAVE_SETLOCALE 1

/* Define to 1 if you have the <signal.h> header file. */
#define HAVE_SIGNAL_H 1

/* Define to 1 if you have the `socket' function. */
/* #undef HAVE_SOCKET */

/* Define to 1 if you have the <stdlib.h> header file. */
#define HAVE_STDLIB_H 1

/* Define to 1 if you have the `strcasecmp' function. */
/* #undef HAVE_STRCASECMP */

/* Redefinition of strcasecmp for WIN32 */
#define strcasecmp _stricmp

/* Redefinition of __attribute__ for WIN32 */
#ifndef __GNUC__ 
#define  __attribute__(x)  /*NOTHING*/ 
#endif

/*Using boost::throw_exception and not our own*/
#define _CPPUNWIND 1

/* Define to 1 if you have the `strerror' function. */
#define HAVE_STRERROR 1

/* Define to 1 if you have the <strings.h> header file. */
/* #undef HAVE_STRINGS_H */

/* Define to 1 if you have the <string.h> header file. */
#define HAVE_STRING_H 1

/* Define to 1 if you have the `strtoul' function. */
#define HAVE_STRTOUL 1

/* Define to 1 if you have the <syslog.h> header file. */
/* #undef HAVE_SYSLOG_H */

/* Define to 1 if you have the <sys/ioctl.h> header file. */
/* #undef HAVE_SYS_IOCTL_H */

/* Define to 1 if you have the <sys/resource.h> header file. */
/* #undef HAVE_SYS_RESOURCE_H */

/* Define to 1 if you have the <sys/socket.h> header file. */
/* #undef HAVE_SYS_SOCKET_H */

/* Define to 1 if you have the <sys/stat.h> header file. */
#define HAVE_SYS_STAT_H 1

/* Define to 1 if you have the <sys/time.h> header file. */
/* #undef HAVE_SYS_TIME_H */

/* Define to 1 if you have the <sys/types.h> header file. */
#define HAVE_SYS_TYPES_H 1

/* Define to 1 if you have the <sys/wait.h> header file. */
/* #undef HAVE_SYS_WAIT_H */

/* Define to 1 if you have the <termios.h> header file. */
/* #undef HAVE_TERMIOS_H */

/* Define to 1 if you have the <time.h> header file. */
#define HAVE_TIME_H 1

/* Define to 1 if you have the <unistd.h> header file. */
/* #undef HAVE_UNISTD_H */

/* Define to 1 if you have the `vfork' function. */
/* #undef HAVE_VFORK */

/* Define to 1 if you have the <vfork.h> header file. */
/* #undef HAVE_VFORK_H */

/* Define to 1 if you have the `vprintf' function. */
#define HAVE_VPRINTF 1

/* Define to 1 if you have the <windows.h> header file. */
#define HAVE_WINDOWS_H 1

/* Define to 1 if you have the <winsock2.h> header file. */
#define HAVE_WINSOCK2_H 1

/* Define to 1 if `fork' works. */
/* #undef HAVE_WORKING_FORK */

/* Define to 1 if `vfork' works. */
/* #undef HAVE_WORKING_VFORK */

/* Define to 1 if the system has the type `_Bool'. */
/* #undef HAVE__BOOL */

/* Name of package */
#define PACKAGE "wsgate"

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT "cboicu@cloudbasesolutions.com"

/* Define to the full name of this package. */
#define PACKAGE_NAME "FreeRDP-WebConnect"

/* Define to the full name and version of this package. */
#define PACKAGE_STRING "FreeRDP-WebConnect-"

/* Define to the one symbol short name of this package. */
/* #undef PACKAGE_TARNAME */

/* Define to the home page for this package. */
#define PACKAGE_URL "https://github.com/Cloudbase/FreeRDP-WebConnect"

/* Define to the version of this package. */
/* #undef PACKAGE_VERSION */

/* Define to 1 if you have the ANSI C header files. */
/* #undef STDC_HEADERS */

/* Define, if using bfd for resolving symbols */
/* #undef USE_BFD */

/* Define, if using libdw for resolving symbols */
/* #undef USE_DWARF */

/* Version number of package */
#define VERSION "1.2.0"

/* Whether to compile with debugging information */
/* #undef WSGATE_DEBUG */

/* Select wide string variants */
#define _UNICODE 1

/* Minimum Windows version (XP) */
/* #define _WIN32_WINNT 0x0501 */

#define WIN32 1
#define _WIN32 1

/*Defining the usleep on windows*/
#ifdef _WIN32 
#define usleep(x) Sleep(x/1000)
#endif


/*Defining the chdir on windows*/
#ifdef _WIN32 
#define chdir _chdir
#endif

/* Define to empty if `const' does not conform to ANSI C. */
/* #undef const */

/* Define to `__inline__' or `__inline' if that's what the C compiler
   calls it, or to nothing if 'inline' is not supported under any name.  */
#ifndef __cplusplus
/* #undef inline */
#endif

/* Define to `int' if <sys/types.h> does not define. */
/* #undef pid_t */

/* Define to `unsigned int' if <sys/types.h> does not define. */
/* #undef size_t */

/* Define as `fork' if `vfork' does not work. */
/* #undef vfork */

#define FREERDP_VERSION 20
