/* check if compiler defines __PRETTY_FUNCTION__ */
int main()
{
	const char* name = __PRETTY_FUNCTION__;
}